from .primaldimer_py import *

__doc__ = primaldimer_py.__doc__
if hasattr(primaldimer_py, "__all__"):
    __all__ = primaldimer_py.__all__