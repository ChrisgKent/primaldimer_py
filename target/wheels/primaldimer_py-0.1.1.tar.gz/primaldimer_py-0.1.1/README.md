# primaldimer_py
Python bindings for the primaldimer_rs

## Requirements 
mautrin https://www.maturin.rs/index.html

## Instalation 

```
git clone --recurse-submodules https://github.com/ChrisgKent/primaldimer_py

cd primaldimer_py
maturin build --release

pip install {path of wheel}
```
