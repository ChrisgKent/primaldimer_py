![Tests](https://github.com/ChrisgKent/primaldimer_rs/actions/workflows/rust.yml/badge.svg)

# primaldimer_rs
Rust implementation of PrimalDimer
